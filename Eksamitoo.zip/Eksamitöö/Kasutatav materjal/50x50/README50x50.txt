Andmed:
LEM EKSAM nr 4 50x50 Andmed Siit.modfem
LEM EKSAM nr 4 NELJANDIK -50x50 EL.txt
LEM EKSAM nr 4 NELJANDIK -50x50 NODES.txt
femapi n�ide:
LEM EKSAM NR 4 50x50 N�ide siin.modfem
mathcad:
LEM-EKSAM-4-andmed_sees-50x50_1.xmcd

-Mart