Andmed:
LEM EKSAM nr 4 -NELJANDIK.modfem
LEM-EKSAM-4-andmed_sees-WIP.xmcd
LEM EKSAM nr 4 NELJANDIK - NODES.txt
femapi n�ide:
LEM EKSAM NR 4 - UUS KATSE (NELINURK)-MORE DONE.modfem
mathcad:
LEM-EKSAM-4-andmed_sees-WIP.xmcd
mathcadi tulemus:
LEM-EKSAM-4-andmed_sees-WIP.xmcd

-Mart