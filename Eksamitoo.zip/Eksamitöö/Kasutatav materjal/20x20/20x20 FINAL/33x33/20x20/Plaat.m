%Eeldan, et kasutan neljandikku skeemist
%
%
%

function Plaat(ELtxt,NOtxt)
JaotK=100; %MPa. Jaotuatud koormus, pos: x-pos. suunas
t=12; %mm. Plaadi paksus
h=1000; %mm. Plaadi k�rgus. (modelleeritud osa!)
Ap=t*h; %mm^2. Koormuse m�jupindala
KP=1000; %mm. Koormatud punktide koordinaat
         %Punktid peavad asuma x v�i y teljega paralleelsel sirgel
xy=1;   %kas x v�i y teljel. 1 - x, 2 - y
PM=6; %mm. pluss-miinus
ATx=0;   %punktide, mille y-siire on kinni, x-koordinaat
ATy=0;   %punktide, milly x-siire on kinni, y-koordinaat
Jy=150;  % otsitava joone y-koordinaat
if arvutKFUW(ELtxt,NOtxt) == [1;1;1;1] 
    display('V�ga hea! Selliste andmetega olen juba arvutanud!');
    Kglob=dlmread(strcat('KGLOB_',ELtxt,'_',NOtxt,'.txt'));
    display('Kglob leitud ja loetud');
    Fglob=dlmread(strcat('FGLOB_',ELtxt,'_',NOtxt,'.txt'));
    display('Fglob leitud ja loetud');
    U=dlmread(strcat('U_',ELtxt,'_',NOtxt,'.txt'));
    display('U maatriks leitud ja loetud');
    WT=dlmread(strcat('WT_',ELtxt,'_',NOtxt,'.txt'));
    display('Siirded leitud ja loetud');
else
    % File does not exist.
    Arvut=arvutKFUW(ELtxt,NOtxt);
    display('Selliste Andmetega pole veel (v�hemalt l�puni) arvutanud.');
    EL=dlmread(ELtxt);
    NO=dlmread(NOtxt);
    E=210*10^3; %MPa
    ny=0.3;
    size(NO);
    size(EL);
    WI=([[-1/3^.5,1];[1/3^.5,1]]);
    WII=([[-1/3^.5,1];[1/3^.5,1]]);
    [wNO,hNO]=size(NO);
    [wEL,hEL]=size(EL);
    A=findNO(EL,wNO,wEL);   %siin eeldatakse, et node'ide j�rje-
    if ~isempty(A)          %korranumber kattub maatriksi omaga
        NO=deleteNOs(NO,A);
    end;
    C=([[E/(1-ny^2),ny*E/(1-ny^2),0];[ny*E/(1-ny^2),E/(1-ny^2),0];[0,0,E/(2*(1+ny))]]);
    [wNO,hNO]=size(NO);
    %Kel(1,WI,WII,C,wNO,NO,EL)    %~VIGA!
    %B(390,3^(-0.5),3^(-0.5),wNO,NO,EL); %~VIGA!
    % for i = 1:2
    %     for j=1:2
    %         B(1,WI(j,1),WII(i,1),wNO,NO,EL)'
    %     end;
    % end;
    %Kel(wEL,WI,WII,C,wNO,NO,EL)    %~VIGA!
    if ~Arvut(1)
        display('Hakkan globaalset j�ikusmaatriksit tegema');
        Kglob=Kglobf(wNO,wEL,WI,WII,C,NO,EL);
        dlmwrite(strcat('KGLOB_',ELtxt,'_',NOtxt,'.txt'),Kglob);
        display('Globaalne j�ikusmaatriks valmis ja kirjutatud');
    else
        display('Kglob juba olemas. Loen.');
        Kglob=dlmread(strcat('KGLOB_',ELtxt,'_',NOtxt,'.txt'));
        display('Kglob loetud');
    end;
    KPd=KPf(KP,xy,PM,NO,wNO);
    if ~Arvut(2)
        Fglob=Fglobf(JaotK,KPd,xy,Ap,NO,wNO);
        dlmwrite(strcat('FGLOB_',ELtxt,'_',NOtxt,'.txt'),Fglob);
        display('Fglob valmis ja kirjutatud');
    else
        display('Fglob juba olemas. Loen');
        Fglob=dlmread(strcat('FGLOB_',ELtxt,'_',NOtxt,'.txt'));
        display('Fglob loetud');
    end;
    if ~Arvut(3)
        punktid=punktidf(ATx,ATy,PM,NO,wNO);
        U=ULoom(wNO,punktid);
        dlmwrite(strcat('U_',ELtxt,'_',NOtxt,'.txt'),U);
        display('U maatriks valmis ja kirjutatud');
    else
        display('U maatriks on juba olemas. Loen');
        U=dlmread(strcat('U_',ELtxt,'_',NOtxt,'.txt'));
        display('U loetud');
    end;
    if ~Arvut(4)
        W=inv(U*Kglob*U')*(U*Fglob);
        display('Siirded arvutatud');
        WT=U'*W;
        dlmwrite(strcat('WT_',ELtxt,'_',NOtxt,'.txt'),WT);
        display('T�ielikud siirded leitud ja kirjutatud');
    else
        display('Siirded juba olemas. Loen');
        WT=dlmread(strcat('WT_',ELtxt,'_',NOtxt,'.txt'));
        display('Siirded loetud');
    end;
end;
EL=dlmread(ELtxt);
NO=dlmread(NOtxt);
[wNO,hNO]=size(NO);  %CODE DOUBLED
[wEL,hEL]=size(EL);  %NEED to fix something
A=findNO(EL,wNO,wEL);   %siin eeldatakse, et node'ide j�rje-
if ~isempty(A)          %korranumber kattub maatriksi omaga
    NO=deleteNOs(NO,A);
end;
[wNO,hNO]=size(NO);
Joon=Joonf(NO,Jy,PM);
[Siirex, Siirey]=Siirded(WT,Joon);
[WTx, WTy]=WTxy(WT,wNO);
X=NO(:,2);
Y=NO(:,3);
plot(X,Y,'*',X+100*WTx,Y+100*WTy,'*');
end 

function [X Y]=WTxy(WT,n)
X=zeros(n,1);
Y=zeros(n,1);
for i=1:n
    X(i)=WT(2*i-1);
    Y(i)=WT(2*i);
end;
end

function [X Y]=Siirded(WT,Joon)
X=zeros(length(Joon),1);
Y=zeros(length(Joon),1);
for i=1:length(Joon)
    X(i)=WT(2*Joon(i)-1);
    Y(i)=WT(2*Joon(i));
end;
end

function R=Joonf(NO,y,PM);
n=51;    %k�sitsi sisestatud number. andmete vahetamisel vaja vahetada
Joon=zeros(n,1);
j=1;
for i =1:length(NO)
    if abs(NO(i,3)-y)<=PM
        Joon(j)=i;
        j=j+1;
    end;
end;
Joon(j)=91;              %MANUAALSELT LISATUD s�lmed
Joon(j+1)=6892;          %Joonele! Andmete vahetusel vahetada!
Joon(j+2)=6897;
Joon(j+3)=6894;
xJoon=zeros(n,1);
for i=1:length(Joon)
    xJoon(i)=NO(Joon(i),2);
end;
R2=sort(xJoon);
R=zeros(n,1);
for i=1:length(Joon)
    r=0;
    j=1;
    while r==0
        if R2(i)==xJoon(j)
            R(i)=Joon(j);
            r=1;
        end;
    j=j+1;
    end;
end;
end

function R=arvutKFUW(ELtxt,NOtxt)
R=zeros(4,1);
if exist(strcat('KGLOB_',ELtxt,'_',NOtxt,'.txt'), 'file')
    R(1)=1;
end;
if exist(strcat('FGLOB_',ELtxt,'_',NOtxt,'.txt'), 'file')
    R(2)=1;
end;
if exist(strcat('U_',ELtxt,'_',NOtxt,'.txt'), 'file')
    R(3)=1;
end;
if exist(strcat('WT_',ELtxt,'_',NOtxt,'.txt'), 'file')
    R(4)=1;
end;
end


function R=ULoom(wNO,punktid)
r=U_sisestuskontroll(wNO,punktid);
if r==1 
    display('��retingimuste viga. ��retingimus m��ratud s�lmele, mida ei ole, v�i vabadusastmeks m��ratud midagi muud peale 1 v�i 0');
    return;
elseif r==2
    display('��retingimuste viga. Punktide j�rjekorranumbrid peavad olmea suurenevas j�rjekorras');
    return;
elseif r==3   %sisestuskontroll on automaatse punktide maatriksi tegemise korral �sna m�ttetu
    display('��retingimuste viga. Punktide j�rjekorranumbrid peavad olema suurenevas j�rjekorras. Sisesta ainult s�lme numbreid, mis on olmes. Vabadusastmeks m�rgi 1 v�i 0.');
    return;
end;
[w h]=size(punktid);
va=h-1;
kinni=0;
for i=1:w
    for j=2:h
        kinni=kinni+punktid(i,j);
    end;
end;
R=zeros(va*wNO-kinni,va*wNO);  %k�sitsi sisestatud number. andmete muutmisel vahetada
m=0;
k=0;
for p=1:w
    if and((va*(punktid(p,1)-1)>m+1),or(punktid(p,2)==1,punktid(p,3)==1))
        m=m+1;
        for i=m:va*(punktid(p,1)-1)
            R(i-k,i)=1;
            m=i;
        end;
    end;
    for pk=2:h
        m=m+1;
        if punktid(p,pk)==1
            k=k+1;
        end;
        if punktid(p,pk)==0
            R(m-k,m)=1;
        end;
    end;
end;
if m<va*wNO
    for i=m+1:va*wNO
        R(i-k,i)=1;
    end;
end;
end

function R=U_sisestuskontroll(n,punktid)
r=0;
r2=0;
for i=1:length(punktid)
    if or(punktid(i,1)>n,punktid(i,1)<=0)
        r=1;
        display('Punkt ei kuulu s�lmede hulka');
    end
    for j=2:3
        if or(punktid(i,j)<0,punktid(j,j)>1)
            r=1;
            display('Vabadusaste peab olmea 1 v�i 0');
        end
    end
end
for i=2:length(punktid)
    if punktid(i,1)<=punktid(i-1,1)
        r2=2;
        display('punktide j�rjekorranumbrid peavad algama v�ikseimast ja l�ppema suurigaa');
    end
    R=r+r2;
end;
end


function R=punktidf(x,y,PM,NO,wNO)
j=1;
R=zeros(54,3);     %manuaalselt pandud number. uue v�rgu korral muuta
for i=1:wNO
    if abs(NO(i,3)-y)<=PM
        R(j,1)=i;
        R(j,3)=1;
        j=j+1;
        if abs(NO(i,2)-x)<10
            j=j-1;
        end;
    end;
    if abs(NO(i,2)-x)<=PM
        R(j,1)=i;
        R(j,2)=1;
        j=j+1;
    end;
end;
end

function R=findel2(no,NO,wNO)
for i=1:wNO
    if NO(i,1)==no
        R=i;
    end;
end;
end

function R=Fglobf(JK,KP,xy,A,NO,wNO)
KJ=JK*A; %N
n=length(KP);
kesk=KJ/(n-1);
nurk=1/2*kesk;
NP=[findel2(195,NO,wNO);findel2(295,NO,wNO)];  %siin m�rgin manuaalselt ��ra nurgapunktid
R=zeros(2*wNO,1);
for i=1:length(KP)
    R(2*KP(i)+xy-2)=kesk;  %paneb ise j�u x v�i y suunale
end;
R(2*NP(1)+xy-2)=nurk;    %nurgad saavad erinevad
R(2*NP(2)+xy-2)=nurk;    %koormuse. daah
end

function R=KPf(KP,xy,PM,NO,wNO)
j=1;
R=zeros(51,1);     %manuaalne number. andmete vahetusel peaks vahetama
for i=1:wNO
    if abs((NO(i,xy+1)-KP))<=PM
        R(j)=i;
        j=j+1;
    end;
end;
end

function R=maxmod(Array)
[w h]=size(Array);
max=0;
for i=1:w
    for j=1:h
        if abs(max) < abs(Array(i,j))
            max=Array(i,j);
            maxi=i;
            maxj=j;
        end;
    end;
end;
R=[max maxi maxj];
end

function R=Kglobf(wNO,wEL,WI,WII,C,NO,EL)
R=zeros(2*wNO);
for el=1:wEL
    Ka=Kel(el,WI,WII,C,wNO,NO,EL);
    for i=1:4
        for j=1:4
            for k=1:2
                for m=1:2
                    R((findel(el,i,wNO,NO,EL)-1)*2+k,(findel(el,j,wNO,NO,EL)-1)*2+m)=R((findel(el,i,wNO,NO,EL)-1)*2+k,(findel(el,j,wNO,NO,EL)-1)*2+m)+Ka(2*(i-1)+k,2*(j-1)+m);
                end;
            end;
        end;
    end;
end;
end


function R=Kel(el,WI,WII,C,wNO,NO,EL)
R=zeros(8);
for i=1:2
    for j=1:2
        R=R+WI(j,2)*WII(i,2)*B(el,WI(j,1),WII(i,1),wNO,NO,EL)'*C*B(el,WI(j,1),WII(i,1),wNO,NO,EL)*det(J(el,WI(j,1),WII(i,1),wNO,NO,EL));
    end;
end;
R=12*R;
end

function R=findel(el,i,wNO,NO,EL)
for j=1:wNO
    if NO(j,1)==EL(el,i)
        R=j;
    end;
end;
end

function R=J(el,e,n,wNO,NO,EL)
for i=1:4
    M(1,i)=dfide(e,n,i);
    M(2,i)=dfidn(e,n,i);
end;
for i=1:4
    COR(i,1)=NO(findel(el,i,wNO,NO,EL),2);
    COR(i,2)=NO(findel(el,i,wNO,NO,EL),3);
end;
R=M*COR;
end


function R=B(el,e,n,wNO,NO,EL)
R=zeros(3,8);
for i=1:4
    Vdfixy=inv(J(el,e,n,wNO,NO,EL))*[dfide(e,n,i);dfidn(e,n,i)];
    R(1,2*i-1)=Vdfixy(1);
    R(2,2*i)=Vdfixy(2);
    R(3,2*i-1)=Vdfixy(2);
    R(3,2*i)=Vdfixy(1); 
end
end

function R=dfide(e,n,i)
if i==1
    R=-1/4*(1-n);
elseif i==2
    R=1/4*(1-n);
elseif i==4
    R=-1/4*(1+n);
elseif i==3
    R=1/4*(1+n);
end;
end

function R=dfidn(e,n,i)
if i==1
    R=-1/4*(1-e);
elseif i==2
    R=-1/4*(1+e);
elseif i==4
    R=1/4*(1-e);
elseif i==3
    R=1/4*(1+e);
end; 
end

function R=findNO(EL,wNO,wEL)
j=0;
for no=1:wNO
    r=0;
    for el=1:wEL
        for i=1:4
            if EL(el,i)==no 
                r=r+1;
            end;
        end;
    end;
    if r==0 
        j=j+1;
    end;
end;
R=zeros([j,1]);
j=1;
for no=1:wNO
    r=0;
    for el=1:wEL
        for i=1:4
            if EL(el,i)==no 
                r=r+1;
            end;
        end;
    end;
    if r==0 
        R(j)=no;
        j=j+1;
    end;
end;
end

function R=deleteNOs(NO,A)
R=NO;
for i=1:length(A)
    R=deleteNO(A(i),R,i-1);
end;
end

function R=deleteNO(no,NO,r)
[w h]=size(NO);
R=zeros([w-1,4]);
for i=1:no-r
    for j=1:4
        R(i,j)=NO(i,j);
    end;
end;
for i=no-r:w-1
    for j=1:4
        R(i,j)=NO(i+1,j);
    end;
end;
end
