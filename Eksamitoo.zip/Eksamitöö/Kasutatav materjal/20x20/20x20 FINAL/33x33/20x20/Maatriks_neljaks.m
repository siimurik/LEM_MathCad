function Maatriks_neljaks(ELtxt,NOtxt)
R=zeros(4,1);
if exist(strcat('KGLOB_',ELtxt,'_',NOtxt,'.txt'), 'file')
    R(1)=1;
end;
if exist(strcat('FGLOB_',ELtxt,'_',NOtxt,'.txt'), 'file')
    R(2)=1;
end;
if exist(strcat('U_',ELtxt,'_',NOtxt,'.txt'), 'file')
    R(3)=1;
end;
if exist(strcat('WT_',ELtxt,'_',NOtxt,'.txt'), 'file')
    R(4)=1;
end;
% if R(1) 
%     display('Hakkan j�ikusmaatriksit t�kkideks jagama');
%     too_jaam(ELtxt,NOtxt,'KGLOB_');
% end;
if R(2) 
    display('Hakkan j�uvektorit t�kkideks jagama');
    too_jaam(ELtxt,NOtxt,'FGLOB_');  %proovin l�bi FGLOBIGA
end;
if R(3) 
    display('Hakkan U maatriksit t�kkideks jagama');
    too_jaam(ELtxt,NOtxt,'U_');
end;
if R(4) 
    display('Hakkan siirdeid t�kkideks jagama');
    too_jaam(ELtxt,NOtxt,'WT_');
end;
display('K�ik olemasolevad maatriksid jaotatud');
end

function too_jaam(ELtxt,NOtxt,Nimi);
M=dlmread(strcat(Nimi,ELtxt,'_',NOtxt,'.txt'));
[w h]=size(M)
if h==1
    dlmwrite(strcat(Nimi,ELtxt,'_',NOtxt,'_1.txt'),M(1:length(M)/2));
    dlmwrite(strcat(Nimi,ELtxt,'_',NOtxt,'_2.txt'),M(length(M)/2+1:length(M)));
else
    dlmwrite(strcat(Nimi,ELtxt,'_',NOtxt,'_1.txt'),M(1:w/2,1:h/2));
    dlmwrite(strcat(Nimi,ELtxt,'_',NOtxt,'_2.txt'),M(1:w/2,h/2+1:h));
    dlmwrite(strcat(Nimi,ELtxt,'_',NOtxt,'_3.txt'),M(w/2+1:w,1:h/2));
    dlmwrite(strcat(Nimi,ELtxt,'_',NOtxt,'_4.txt'),M(w/2+1:w,h/2+1:h));
end;
end



