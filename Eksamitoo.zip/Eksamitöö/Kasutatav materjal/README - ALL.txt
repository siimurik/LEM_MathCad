Koodid, mis peaks t��tama:
50x50:
mathcad ja femap, algandmed
20x20:
NB! Natuke kahtlased kujundid, kui �igesti m�letan
mathcad ja femap, algandmed
20x20/20x20 FINAL/33x33:
mathcad ja femap, algandmed
v�ikseim skeem, millega �nnestus Mathcadi kasutades arvutada
20x20/20x20 FINAL/33x33/20x20:
MATLAB. andmed femapist.
v�imaldab arvutada ka 10x10mm skeemiga (sel juhul v�tab aega ja resurssi, �ra looda samal ajal midagi muud teha)

LEM raport.docx sisaldab �ppej�ule esitatud raportit(NB! 10x10mm ja 20x20mm skeemi arvutasin hiljem juurde, seda seal ei kajastu)


Igal t��taval variandil peakso olema oma README

-Mart
